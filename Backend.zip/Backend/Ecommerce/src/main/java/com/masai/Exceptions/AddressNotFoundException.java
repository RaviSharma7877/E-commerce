package com.masai.Exceptions;

public class AddressNotFoundException extends RuntimeException{

	public AddressNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
