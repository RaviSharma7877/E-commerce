package com.masai.ServicesImpl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.masai.Exceptions.UserNotFoundException;
import com.masai.Repository.UserRepo;
import com.masai.Services.UserServies;
import com.masai.models.User;

@Service
public class UserServiceImpl implements UserServies {
	private UserRepo userRepo;
	
	
	public UserServiceImpl(UserRepo userRepo) {
		this.userRepo = userRepo;
	}

	@Override
	public User UserRegisterUser(User us) {
		return userRepo.save(us);
	}
	
	@Override
	public String UserLogin(String username, String pass) {
		return null;
	}

	@Override
	public List<User> AdmingetAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User UserupdateUserPasswoed(Integer id, String pass) {
		User user = userRepo.findById(id).orElseThrow(() -> new UserNotFoundException("No user exist with id:- " + id));
		user.setPasswordHash(pass);
		return userRepo.save(user);
		
	}

	@Override
	public String AdmindeleteUser(Integer id) {
		User user = userRepo.findById(id).orElseThrow(() -> new UserNotFoundException("No user exist" + id));
		userRepo.delete(user);
		return "User deleted successfully";
	}

	
}
