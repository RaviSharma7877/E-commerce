package com.masai.ServicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.Repository.CategoryRepository;
import com.masai.Services.CategoryService;
import com.masai.models.Categories;

@Service
public class CategoryServiceImpl implements CategoryService{
	 private CategoryRepository categoryRepository;

	    @Autowired
	    public void CategoryService(CategoryRepository categoryRepository) {
	        this.categoryRepository = categoryRepository;
	    }
	    
	    public List<Categories> getAllCategories() {
	        return categoryRepository.findAll();
	    }

	    public Categories addCategory(Categories category) {
	        return categoryRepository.save(category);
	    }
}
