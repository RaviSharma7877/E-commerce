package com.masai.Services;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.masai.models.Coupons;

public interface CouponService {
	public Coupons addCoupons(Coupons us);
	public Coupons updateCouponDiscount(Integer id, BigDecimal discountPercentage);
	public Coupons updateCouponExpiryDate(Integer id, LocalDate expirationDate);
	public String deleteCoupons(Integer id);
}
