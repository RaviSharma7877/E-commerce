package com.masai.Services;

import java.math.BigDecimal;
import java.util.List;

import com.masai.models.Products;

public interface ProductService {
	public Products addProducts(Products us);
	public List<Products> AdmingetAllProducts();
	public Products updateProductsPrice(Integer id, BigDecimal price);
	public String deleteProducts(Integer id);
}
