package com.masai.Services;

import java.util.List;

import com.masai.models.Categories;

public interface CategoryService {
	public Categories addCategory(Categories category);
	public List<Categories> getAllCategories();
}
