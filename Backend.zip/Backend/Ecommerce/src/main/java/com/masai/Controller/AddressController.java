package com.masai.Controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.Services.AddressService;
import com.masai.models.Address;

@RestController
@RequestMapping("/addresses")
public class AddressController {
private AddressService addressService;

public AddressController(AddressService addressService) {
	super();
	this.addressService = addressService;
}

@PostMapping("/address")
public Address addAddress(@RequestBody Address us) {
	return addressService.addAddress(us);
}

@PatchMapping
public Address updateUserAddress(Integer id, String addressType) {
	return addressService.updateUserAddress(id, addressType);
}

@DeleteMapping
public String deleteAddress(Integer id) {
	return addressService.deleteAddress(id);
}
}
