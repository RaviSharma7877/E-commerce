package com.masai.Services;

import java.util.List;


import com.masai.models.User;

public interface UserServies{
	public User UserRegisterUser(User us);
	public String UserLogin(String username, String pass);
	public List<User> AdmingetAllUsers();
	public User UserupdateUserPasswoed(Integer id, String pass);
	public String AdmindeleteUser(Integer id);
}
