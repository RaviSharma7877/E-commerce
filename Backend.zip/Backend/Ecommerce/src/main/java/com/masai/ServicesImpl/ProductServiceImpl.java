package com.masai.ServicesImpl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.masai.Exceptions.UserNotFoundException;
import com.masai.Repository.ProductRepo;
import com.masai.Services.ProductService;
import com.masai.models.Products;
import com.masai.models.User;

@Service
public class ProductServiceImpl implements ProductService{

	private ProductRepo productRepo;
	
	
	public ProductServiceImpl(ProductRepo productRepo) {
		super();
		this.productRepo = productRepo;
	}

	@Override
	public Products addProducts(Products us) {
		return productRepo.save(us);
	}

	@Override
	public List<Products> AdmingetAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public Products updateProductsPrice(Integer id, BigDecimal price) {
		Products product = productRepo.findById(id).orElseThrow(() -> new UserNotFoundException("No user exist with id:- " + id));
		product.setPrice(price);
		return productRepo.save(product);
	}

	@Override
	public String deleteProducts(Integer id) {
		Products product = productRepo.findById(id).orElseThrow(() -> new UserNotFoundException("No user exist with id:- " + id));
		productRepo.delete(product);
		return "Product deleted successully";
	}

}
