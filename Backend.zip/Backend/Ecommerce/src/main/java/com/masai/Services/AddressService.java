package com.masai.Services;

import java.math.BigDecimal;
import java.util.List;

import com.masai.models.Address;

public interface AddressService {
	public Address addAddress(Address us);
	public Address updateUserAddress(Integer id, String addressType);
	public String deleteAddress(Integer id);
}
