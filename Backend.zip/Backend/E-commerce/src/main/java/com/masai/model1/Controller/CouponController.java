package com.masai.model1.Controller;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.model1.Services.CouponService;
import com.masai.model1.models.Coupons;

@RestController
@RequestMapping("/coupons")
public class CouponController {
	private CouponService couponService;

	public CouponController(CouponService couponService) {
		super();
		this.couponService = couponService;
	}
	
	@PostMapping("/addCoupon")
	public Coupons addCoupons(Coupons us) {
		return couponService.addCoupons(us);
	}
	
	@PatchMapping("/updatecoupondiscount")
	public Coupons updateCouponDiscount(Integer id, BigDecimal discountPercentage) {
		return couponService.updateCouponDiscount(id, discountPercentage);
	}
	
	@PatchMapping("/updatecouponExpiryDate")
	public Coupons updateCouponExpiryDate(Integer id, LocalDate expirationDate) {
		return couponService.updateCouponExpiryDate(id, expirationDate);
	}
	
	@DeleteMapping("/deletecoupon")
	public String deleteAddress(Integer id) {
		return couponService.deleteCoupons(id);
	}
}
