package com.masai.model1.Exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(NoHandlerFoundException.class)
	public ResponseEntity<ErrorDetails> getExceptionNoHandler(NoHandlerFoundException ex, WebRequest request){
		ErrorDetails ed = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<ErrorDetails>(ed,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AddressNotFoundException.class)
	public ResponseEntity<ErrorDetails> addressnotfound(AddressNotFoundException ex, WebRequest request){
		LocalDateTime now = LocalDateTime.now();
		String uri = request.getDescription(false);
		ErrorDetails ed = new ErrorDetails(now, ex.getMessage(), uri);
		return new ResponseEntity<ErrorDetails>(ed,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(CouponNotFoundException.class)
	public ResponseEntity<ErrorDetails> couponnotfound(CouponNotFoundException ex, WebRequest request){
		LocalDateTime now = LocalDateTime.now();
		String uri = request.getDescription(false);
		ErrorDetails ed = new ErrorDetails(now, ex.getMessage(), uri);
		return new ResponseEntity<ErrorDetails>(ed,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ErrorDetails> usernotfound(UserNotFoundException ex, WebRequest request){
		LocalDateTime now = LocalDateTime.now();
		String uri = request.getDescription(false);
		ErrorDetails ed = new ErrorDetails(now, ex.getMessage(), uri);
		return new ResponseEntity<ErrorDetails>(ed,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorDetails> productnotfound(ProductNotFoundException ex, WebRequest request){
		LocalDateTime now = LocalDateTime.now();
		String uri = request.getDescription(false);
		ErrorDetails ed = new ErrorDetails(now, ex.getMessage(), uri);
		return new ResponseEntity<ErrorDetails>(ed,HttpStatus.NOT_FOUND);
	}
	
	
}
