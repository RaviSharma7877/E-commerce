package com.masai.ServicesImpl;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.masai.model1.Exceptions.CouponNotFoundException;
import com.masai.model1.Repository.CouponRepo;
import com.masai.model1.Services.CouponService;
import com.masai.model1.models.Coupons;

public class CouponServiceImpl implements CouponService {

	private CouponRepo couponRepo;
	
	public CouponServiceImpl(CouponRepo couponRepo) {
		super();
		this.couponRepo = couponRepo;
	}

	@Override
	public Coupons addCoupons(Coupons us) {
		return couponRepo.save(us);
	}

	@Override
	public Coupons updateCouponDiscount(Integer id, BigDecimal discountPercentage) {
		Coupons coupon = couponRepo.findById(id).orElseThrow(()-> new CouponNotFoundException("Coupon not found with id:- "+ id));
		coupon.setDiscountPercentage(discountPercentage);
		return couponRepo.save(coupon);
	}

	@Override
	public Coupons updateCouponExpiryDate(Integer id, LocalDate expirationDate) {
		Coupons coupon = couponRepo.findById(id).orElseThrow(()-> new CouponNotFoundException("Coupon not found with id:- "+ id));
		coupon.setExpirationDate(expirationDate);
		return couponRepo.save(coupon);
	}

	@Override
	public String deleteCoupons(Integer id) {
		Coupons coupon = couponRepo.findById(id).orElseThrow(()-> new CouponNotFoundException("Coupon not found with id:- "+ id));
		couponRepo.delete(coupon);
		return "coupon deleted successfully";
	}
	
}
