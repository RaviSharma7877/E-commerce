package com.masai.model1.Services;

import java.util.List;

import com.masai.model1.models.Categories;

public interface CategoryService {
	public Categories addCategory(Categories category);
	public List<Categories> getAllCategories();
}
