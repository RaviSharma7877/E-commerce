package com.masai.model1.Services;

import java.math.BigDecimal;
import java.util.List;

import com.masai.model1.models.Address;

public interface AddressService {
	public Address addAddress(Address us);
	public Address updateUserAddress(Integer id, String addressType);
	public String deleteAddress(Integer id);
}
