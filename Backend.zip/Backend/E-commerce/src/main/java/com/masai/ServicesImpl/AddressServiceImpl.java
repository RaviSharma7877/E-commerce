package com.masai.ServicesImpl;

import org.springframework.stereotype.Service;

import com.masai.model1.Exceptions.AddressNotFoundException;
import com.masai.model1.Repository.AddressRepo;
import com.masai.model1.Services.AddressService;
import com.masai.model1.models.Address;

@Service
public class AddressServiceImpl implements AddressService {

	private AddressRepo addressRepo;
	
	public AddressServiceImpl(AddressRepo addressRepo) {
		super();
		this.addressRepo = addressRepo;
	}

	@Override
	public Address addAddress(Address us) {
		return addressRepo.save(us);
	}

	@Override
	public Address updateUserAddress(Integer id, String addressType) {
		Address address = addressRepo.findById(id).orElseThrow(()-> new AddressNotFoundException("Address not found by id:- "+ id));
//		address.setAddressType(addressType);
		return addressRepo.save(address);
	}

	@Override
	public String deleteAddress(Integer id) {
		Address address = addressRepo.findById(id).orElseThrow(()-> new AddressNotFoundException("Address not found by id:- "+ id));
		addressRepo.delete(address);
		return "Address deleted successfully";
	}

}
