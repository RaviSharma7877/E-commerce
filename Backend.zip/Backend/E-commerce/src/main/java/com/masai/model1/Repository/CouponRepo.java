package com.masai.model1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.model1.models.Coupons;

public interface CouponRepo extends JpaRepository<Coupons, Integer> {

}
