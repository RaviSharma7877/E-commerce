package com.masai.model1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.model1.models.Categories;

public interface CategoryRepository extends JpaRepository<Categories, Long> {
}