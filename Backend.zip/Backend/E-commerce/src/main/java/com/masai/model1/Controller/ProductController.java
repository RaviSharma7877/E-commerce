package com.masai.model1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.model1.Services.ProductService;
import com.masai.model1.models.Products;

@RestController
@RequestMapping("/products")
public class ProductController {
	
		
		private ProductService productService;

		
		@Autowired
		public ProductController(ProductService productService) {
			super();
			this.productService = productService;
		}
		@PostMapping("/addproduct")
		public Products addProducts(@RequestBody Products us) {
			return productService.addProducts(us);
		}
		@GetMapping("/allproducts")
	    public List<Products> AdmingetAllProducts() {
	        return productService.AdmingetAllProducts();
	    }
//		@PatchMapping("/{id}/{pass}")
//		public User UserupdateUserPasswoed(@PathVariable Integer id, @PathVariable String pass) {
//			return userservice.UserupdateUserPasswoed(id, pass);
//		}
//		@DeleteMapping("/{id}")
//		public ResponseEntity<String> AdmindeleteUser(@PathVariable Integer id) {
//			String message = userservice.AdmindeleteUser(id);
//			return new ResponseEntity<String>(message, HttpStatus.OK);
//		}
}
