package com.masai.model1.Exceptions;

public class CouponNotFoundException extends RuntimeException {

	public CouponNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
